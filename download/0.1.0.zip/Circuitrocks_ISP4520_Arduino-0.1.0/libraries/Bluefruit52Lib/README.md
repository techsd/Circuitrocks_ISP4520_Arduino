# Adafruit Feather nRF52 Bluefruit Libraries

Peripherals & Central library