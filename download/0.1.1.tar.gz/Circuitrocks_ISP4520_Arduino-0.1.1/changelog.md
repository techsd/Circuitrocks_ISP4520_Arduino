# Circuitrocks ISP4520 Arduino Core Changelog

## 0.1.1 - 2019.10.06

- Make it a custom package for PlatformIO

## 0.1.0 - 2019.10.06

- Adapted Adafruit nRF52 Arduino sources to work with the Circuitrocks Alora ISP4520 module
